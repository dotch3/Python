import math
def calculate_gcd(a, b):

    if a == 0 or b == 0:
    	return 0

    else :
    	if a > b:
       		 r = a%b
        if r == 0:
            return b
        else:
            return gcd(b, r)
    if a < b:
        a = b
        b = a
        return gcd(a, b)

def create_matrix(x, n):
	if (n % x == 0):
		print x 
		#print n+x	
	if n == 0:
		
		return n
		
	else:
		return  create_matrix(x+1, n-1)



create_matrix(1,3)

# def calculate_things():

# 	x = 1.0
# 	while x < 10.0:
# 		#print x, '\t' , math.log(x)
# 		print "%s \t %s \t %s" % (x, math.log(x),"__") # formateadores de cadena.. reemplaza el % con el "x y elotro valor de la funcion"
# 		x = x +1.0



# calculate_things()

